#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HideImGui : UIView

@property (nonatomic,strong) UITextField *_UITextField;
@property (nonatomic,strong) UIView *_UIView;

@end

NS_ASSUME_NONNULL_END
