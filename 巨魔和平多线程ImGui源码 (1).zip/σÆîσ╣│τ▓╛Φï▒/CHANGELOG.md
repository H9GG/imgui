# Bug Fixes

- Fix a bug in App Intents.
