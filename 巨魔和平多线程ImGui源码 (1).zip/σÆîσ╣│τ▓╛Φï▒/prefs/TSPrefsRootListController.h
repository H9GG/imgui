#import <Preferences/PSListController.h>

@interface TSPrefsRootListController : PSListController

@end
